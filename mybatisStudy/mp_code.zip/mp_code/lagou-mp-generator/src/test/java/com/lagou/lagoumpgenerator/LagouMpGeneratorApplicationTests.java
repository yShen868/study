package com.lagou.lagoumpgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LagouMpGeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
