package com.lagou;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LagouMpGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(LagouMpGeneratorApplication.class, args);
    }

}
