package com.lagou.mp.generator.user.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zimu
 * @since 2020-10-30
 */
@Controller
@RequestMapping("/user/tb-user")
public class TbUserController {

}
