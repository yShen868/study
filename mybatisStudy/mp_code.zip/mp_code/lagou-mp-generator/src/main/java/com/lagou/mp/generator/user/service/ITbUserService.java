package com.lagou.mp.generator.user.service;

import com.lagou.mp.generator.user.entity.TbUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zimu
 * @since 2020-10-30
 */
public interface ITbUserService extends IService<TbUser> {

}
